<div class="container">
	<div class="footer">
		<p style="font-size: 24px">LABORATORY MANAGMENT SYSTEM @ 2021<span style="font-size: 12px;color: yellow;">Muhammad Zia Ur Rehman - BSIT_17-24</span></p>
	</div>
</div>
<script src="js/bootstrap.min.js"></script>  
<script src="jquery/jquery-3.2.1.min.js"></script>
</body>
</html>