<?php 
//$con = mysqli_connect('localhost', 'ANMOL', 'Anmol_122', 'virtual_preparation');
session_start();
$con = mysqli_connect('localhost', 'root', '', 'virtual_preparations'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>V-PREY</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  .affix {
    top: 0;
    width: 100%;
    -webkit-transition: all .5s ease-in-out;
    transition: all .5s ease-in-out;
  }
  .affix-top {
    position: static;
    top: -35px;
  }
  .affix + .container-fluid {
    padding-top: 70px;
  }
  </style>