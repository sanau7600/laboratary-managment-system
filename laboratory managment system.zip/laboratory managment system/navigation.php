<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header"><a class="navbar-brand" href="index.php">LABORATORY MANAGMENT SYSTEM</a></div>
      <ul class="nav nav-tabs navbar-right" style="margin-top: 10px">
        <li role="presentation" class="active"><a href="index.php">Dashboard</a></li>
        <li role="presentation"><a href="categories.php">Categories</a></li>
        <li role="presentation"><a href="patients.php">Patients</a></li>
        <li role="presentation"><a href="tests.php">Tests</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>